const Pool = require('pg').Pool;
require('dotenv').config({path: "./config.txt"});
const pool = new Pool({
    user: process.env.POSTGRES_USERNAME,
    password: process.env.POSTGRES_PASSWORD,
    host: process.env.HOST_IP,
    port: process.env.POSTGRES_PORT,
    database: process.env.POSTGRES_DB,

});

module.exports = pool;


