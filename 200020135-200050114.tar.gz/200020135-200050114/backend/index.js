const express = require('express');
const session = require('express-session');
const app = express();
const cors = require('cors');
const pool = require('./db');
const bcrypt = require('bcryptjs');
const cookieParser = require('cookie-parser')
require('dotenv').config({path: "./config.txt"});

app.use(cors({ origin: process.env.REACT_SERVER_URL, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser())
app.use(express.static(__dirname));


const store = new (require('connect-pg-simple')(session))({
    pool: pool,
})
const isAuth = (req, res, next) => {
    if (req.session.user) {
        if (req.session.user.isAuth) {
            return next()
        }
       
    }
    return res.sendStatus(403)
}

app.use(
    session({
        store: store,
        secret:process.env.SECRET_KEY,
        saveUninitialized: false,
        resave: false,
        cookie: {
            secure: false,
            httpOnly: false,
            sameSite: false,
            maxAge: 1000 * 60 * 60 * 24,
        },
    })
)

app.listen(process.env.NODE_PORT, () => {
    console.log('Server running on port 7500');
    });
    
app.post('/isauth' , (req, res) => {
    if (req.session.user) {
        if (req.session.user.isAuth) {
            return res.json({ user: req.session.user })
        }
    }
    return res.sendStatus(403)


})
// Path: routes/index.js
app.post('/register', async (req, res) => {
    const { username, password } = req.body

    if (username == null ||
        password == null
    ) {
        return res.sendStatus(403)
    }

    try {
        const saltRound = 10;
        const salt = await bcrypt.genSalt(saltRound);
        const hashedPassword = await bcrypt.hash(password, salt);
        // const hashedPassword = bcrypt.hashSync(req.body.password, 10)
        const data = await pool.query(
            'INSERT INTO user_password (id, hashed_password) VALUES ($1, $2) RETURNING *',
            [username, hashedPassword]
        )

        if (data.rows.length === 0) {
            res.sendStatus(403)
        }
        const user = data.rows[0]
        // console.log(user)
        req.session.user = {
            id: user.id,
            isAuth:true
        }

        res.status(200)
        res.redirect('/login')
        // return res.json({ user: req.session.user })
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }
}
)

app.post('/login', async (req, res) => {
    const { username, password } = req.body
    var isStudent = false;
    if (username == null || password == null) {
        return res.sendStatus(403)
    }
    
    try {
        const data = await pool.query(
            'SELECT id, hashed_password FROM user_password WHERE id = $1',
            [username]
        )

        if (data.rows.length === 0) {
            return res.sendStatus(403)
        }
        const user = data.rows[0]
        const matches = await bcrypt.compare(password, user.hashed_password)
        console.log(matches)
        // const matches = bcrypt.compareSync(password, user.hashed_password)
        if (!matches) {
            return res.sendStatus(403)
        }
        const response = await pool.query(
            'select id from instructor where id = $1',[user.id]
        )
        if(response.rows.length === 0){
            isStudent = true;
        }   
        
        req.session.user = {
            id: user.id,
            isAuth:true,
            isStudent:isStudent
        }

        // return res.status(200)
        // res.redirect('/home')
        console.log(JSON.stringify(req.session.user))
        return res.send(JSON.stringify({ user: req.session.user }))
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }
}
)
app.get("/home_data", isAuth, async (req, res) => {
    try {
    user_id = req.session.user.id

    const data = await pool.query(
        'SELECT id, name, dept_name, tot_cred FROM student WHERE id = $1',
        [user_id]
    )
    actual_data = data.rows[0]
    namee = actual_data.name
    dept_namee = actual_data.dept_name
    tot_credd = actual_data.tot_cred
    const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
    curr_course_data_final = curr_course_data.rows[0]
    curr_year = curr_course_data_final.year
    curr_sem = curr_course_data_final.semester
                                                                                                                                                                                
    
    
    const data_course = await pool.query(
       'select year,semester, array_agg(id||\',\'||course_id||\',\'||title||\',\'||sec_id||\',\'||grade ) as rows from takes natural join course where ID=$1 and (year<$2 or (year=$2 and semester!=$3)) group by year,semester order by year desc,case when semester=\'Spring\' then 1 when semester=\'Summer\' then 2 when semester=\'Fall\' then 3 else 4 end asc ',[user_id,curr_year,curr_sem])
        
    console.log(data_course.rows)
    course_data = data_course.rows
    // console.log(course_data)
                                                                                                                                                             
    const final_current_courses = await pool.query(
        ' select distinct course_id, title, credits, grade  from takes natural join course where semester = $1 and year = $2 and id = $3;',[curr_sem,curr_year,user_id]
    )
    curr_course_data_final_final = final_current_courses.rows

    res.json({ "id": user_id, "name": namee, "dept_name": dept_namee, "tot_cred": tot_credd,
    "course_data": course_data, "curr_course_data": curr_course_data_final_final })

    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }
    
})

app.post('/drop', isAuth, async (req, res) => {
    try {
        user_id = req.session.user.id
        course_id = req.body.course_id
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'DELETE FROM takes WHERE id = $1 and course_id = $2 and year = $3 and semester = $4',
            [user_id,course_id,curr_year,curr_sem]
        )
        return res.send(JSON.stringify({ "success": "Dropped!" }))
    } catch (e) {
        console.error(e)
        return res.send(JSON.stringify({ "error": "Couldn't be dropped, try again!" }))
    }
})
app.get('/',(req,res) => {
   
    if(req.session.user){
        if(req.session.user.isAuth){
        res.send("Welcome User <a href=\'/logout'>click to logout</a>");
        }
    }else
    res.sendFile('views/index.html',{root:__dirname})
});


app.get('/logout',(req,res) => {
    try {
    req.session.destroy();
    } catch (e) {
        console.error(e)
        return res.send(JSON.stringify({ "error": "Couldn't be logged out, try again!" }))
    }
    return res.send(JSON.stringify({ "success": "Logged out!" }));
});

app.post('/register_course',isAuth, async(req,res) => {
    try {
        
        course_id = req.body.course_id
        sec_id = req.body.sec_id
        user_id = req.session.user.id
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const pre_req_data = await pool.query('select prereq_id from prereq where course_id = $1 and prereq_id not in (select course_id from takes where id = $2 and (CAST("year" as INTEGER) < $3 or (year = $3 and semester != $4)));',[course_id,user_id,curr_year,curr_sem])
        pre_req_data_final = pre_req_data.rows
        if(pre_req_data_final.length>0){
            return res.send(JSON.stringify({ "error": "Prerequisite not satisfied" }))
        }
        const time_slot_data = await pool.query('select time_slot_id from takes natural join section where id = $1 and year = $2 and semester=$3;', [user_id,curr_year,curr_sem])
        time_slot_data_final = time_slot_data.rows
        console.log(course_id)
        console.log(sec_id)
        const time_slot_data_course = await pool.query('select time_slot_id from section where course_id = $4 and sec_id = $5 and year = $2 and semester = $3 and time_slot_id not in (select time_slot_id from takes natural join section where id = $1 and year = $2 and semester= $3);', [user_id,curr_year,curr_sem, course_id, sec_id])
        time_slot_data_final_course = time_slot_data_course.rows
        // console.log(time_slot_data_final_course)
        if(time_slot_data_final_course.length == 0){
            return res.send(JSON.stringify({ "error": "Time slot conflict" }))
        }


        console.log(user_id,course_id, sec_id, 'Spring','2009', null)
        const data = await pool.query(
            'INSERT INTO takes(id, course_id, sec_id, semester, year, grade) VALUES ($1,$2,$3,$4,$5,$6);',[user_id,course_id, sec_id, curr_sem,curr_year, null]
        )   
    data_final = data.rows
            return res.sendStatus(200)
        } catch (e) {
            console.error(e)
            return res.sendStatus(403)
        }
})


app.get('/fetch_all_courses',isAuth, async(req,res) => {

    try {
        user_id = req.session.user.id
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select course_id,title, sec_id, credits from section natural join course where course_id not in (select course_id from takes where id =$1 and year =$2 and semester =$3) and semester=$3 and year = $2;', [user_id,curr_year,curr_sem]
        )   
    data_final = data.rows
 
    res.json({"curr_course_data": data_final})
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }
})

app.post('/fetch_a_course',isAuth, async(req,res) => {
    
        try {
            user_id = req.session.user.id
            course_id = req.body.course_id
            const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
            curr_course_data_final = curr_course_data.rows[0]
            curr_year = curr_course_data_final.year
            curr_sem = curr_course_data_final.semester
            const data = await pool.query(
                'select course_id,title, sec_id, credits from section natural join course where course_id not in (select course_id from takes where id =$1 and year =$2 and semester =$3) and semester=$3 and year = $2 and course_id=$4;', [user_id,curr_year,curr_sem,course_id]
            )   
        data_final = data.rows
    
        res.json({"curr_course_data": data_final})
        } catch (e) {
            console.error(e)
            return res.sendStatus(403)
        }


})


app.post('/fetch_some_courses',isAuth, async(req,res) => {
    
    try {
        user_id = req.session.user.id
        string_match = req.body.course_id
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select course_id,title, sec_id, credits from section natural join course where course_id not in (select course_id from takes where id =$1 and year =$2 and semester =$3) and semester=$3 and year = $2 and (course_id ilike \'%\' || $4 || \'%\' or title ilike \'%\' || $4 || \'%\');', [user_id,curr_year,curr_sem,string_match]
        )   
    data_final = data.rows

    res.json({"curr_course_data": data_final})
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }


})


app.get('/course_details/:course_id',isAuth, async(req,res) => {
    try {



        course_id = req.params.course_id
        
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select course_id, title, credits from course where course_id = $1', [course_id]
        )   
    data_final = data.rows[0]
    const pre_req_data = await pool.query(
        'select prereq_id from prereq where course_id = $1', [course_id]
    )
    pre_req_data_final = pre_req_data.rows
    
    // const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
    //     curr_course_data_final = curr_course_data.rows[0]
    //     curr_year = curr_course_data_final.year
    //     curr_sem = curr_course_data_final.semester
    const pre_req_data_final_final = []
    for (let i = 0; i < pre_req_data_final.length; i++) {
        const pre_req_data = await pool.query(
            'select course_id, title from course where course_id = $1', [pre_req_data_final[i].prereq_id]
        )
        pre_req_data_final_final.push(pre_req_data.rows[0])
    }
    
    const instructors_data = await pool.query(
        'select distinct teaches.id, name from instructor full outer join teaches on teaches.id = instructor.id where course_id = $1 and year = $2 and semester = $3', [course_id, curr_year, curr_sem]
    )
    instructors_data_final = instructors_data.rows
    console.log(instructors_data_final)
    res.json({"course_details": data_final, "pre_req_data": pre_req_data_final_final, "instructors_data": instructors_data_final})



    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }

})


app.get('/running_courses',isAuth, async(req,res) => {
    try {
        user_id = req.session.user.id
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select distinct dept_name from course full outer join section on section.course_id = course.course_id where semester = $1 and year = $2;', [curr_sem, curr_year]
        )
        data_final = data.rows
        res.json({"running_courses": data_final})
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }



})

app.get('/running_courses_department/:dept_name',isAuth, async(req,res) => {

    try {
        user_id = req.session.user.id
        dept_name = req.params.dept_name
        console.log(dept_name)
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select distinct section.course_id, title from course full outer join section on section.course_id = course.course_id where semester = $1 and year = $2 and dept_name = $3;', [curr_sem, curr_year,dept_name]
        )
        data_final = data.rows
        res.json({"running_courses": data_final})
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }


})


app.get('/instructor_details/:instructor_id',isAuth, async(req,res) => {

    try {
        user_id = req.session.user.id
        instructor_id = req.params.instructor_id
        console.log(instructor_id)
        const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
        curr_course_data_final = curr_course_data.rows[0]
        curr_year = curr_course_data_final.year
        curr_sem = curr_course_data_final.semester
        const data = await pool.query(
            'select distinct name, dept_name from instructor where id = $1;', [instructor_id]
        )
        data_final = data.rows[0]
        const courses_data = await pool.query(
            'select course_id, title from course where course_id in (select distinct section.course_id from section full outer join teaches on (section.course_id = teaches.course_id and section.year = teaches.year and section.semester = teaches.semester and section.sec_id = teaches.sec_id) where section.semester = $1 and section.year = $2 and id = $3) ORDER BY course_id;', [curr_sem, curr_year, instructor_id]
        )
        courses_data_final = courses_data.rows

        const data_course = await pool.query(
            'select year,semester, array_agg(course_id||\',\'||title) as rows from teaches natural join course where ID=$1 and (year<$2 or (year=$2 and semester!=$3)) group by year,semester order by year desc,case when semester=\'Spring\' then 1 when semester=\'Summer\' then 2 when semester=\'Fall\' then 3 else 4 end asc ',[instructor_id,curr_year,curr_sem])
             
         console.log(data_course.rows)
         course_data = data_course.rows
        

        res.json({"instructor_details": data_final, "current_courses_data": courses_data_final, "past_courses_data": course_data})

        

    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }



})
app.get('/all_deparmentssss',isAuth, async(req,res) => {
    try {
        user_id = req.session.user.id
        const data = await pool.query(
            'select distinct dept_name from department'
        )
        data_final = data.rows
        res.json({"all_deparments": data_final})
    }
    catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }

})


app.get('/all_course_in_departmentttt/:dept_name',isAuth, async(req,res) => {

        try {
            dept_name = req.params.dept_name
            user_id = req.session.user.id
            const data = await pool.query(
                'select distinct course_id, title from course where dept_name = $1', [dept_name]
            )
            data_final = data.rows
            res.json({"all_course_in_department": data_final})


        }   catch (e) {
            console.error(e)
            return res.sendStatus(403)
        }
    



})

app.get('/get_all_coursesss',isAuth, async(req,res) => { 
    try {
        user_id = req.session.user.id
        const data = await pool.query(
            'select distinct course_id, title from course'
        )
        data_final = data.rows
        res.json({"all_courses": data_final})
    } catch (e) {
        console.error(e)
        return res.sendStatus(403)
    }


})


app.get('/get_per_student_coursessss/:student_id',isAuth, async(req,res) => {
    try {
        user_id = req.session.user.id
        student_id = req.params.student_id

        if (req.session.user.isStudent == false || user_id == student_id) {

            const data = await pool.query(
                'SELECT id, name, dept_name, tot_cred FROM student WHERE id = $1',
                [student_id]
            )
            actual_data = data.rows[0]
            namee = actual_data.name
            dept_namee = actual_data.dept_name
            tot_credd = actual_data.tot_cred
            const curr_course_data = await pool.query('select year, semester from reg_dates where (current_timestamp- start_time) = (select min(current_timestamp- start_time) from reg_dates);')
            curr_course_data_final = curr_course_data.rows[0]
            curr_year = curr_course_data_final.year
            curr_sem = curr_course_data_final.semester
                                                                                                                                                                                        
            
            
            const data_course = await pool.query(
               'select year,semester, array_agg(id||\',\'||course_id||\',\'||title||\',\'||sec_id||\',\'||grade ) as rows from takes natural join course where ID=$1 and (year<$2 or (year=$2 and semester!=$3)) group by year,semester order by year desc,case when semester=\'Spring\' then 1 when semester=\'Summer\' then 2 when semester=\'Fall\' then 3 else 4 end asc ',[student_id,curr_year,curr_sem])
                
            console.log(data_course.rows)
            course_data = data_course.rows
            // console.log(course_data)
                                                                                                                                                                     
            const final_current_courses = await pool.query(
                ' select distinct course_id, title, credits, grade  from takes natural join course where semester = $1 and year = $2 and id = $3;',[curr_sem,curr_year,student_id]
            )
            curr_course_data_final_final = final_current_courses.rows
        
            res.json({ "id": student_id, "name": namee, "dept_name": dept_namee, "tot_cred": tot_credd,
            "course_data": course_data, "curr_course_data": curr_course_data_final_final })
        
            } } catch (e) {
                console.error(e)
                return res.sendStatus(403)
            }
        
})

