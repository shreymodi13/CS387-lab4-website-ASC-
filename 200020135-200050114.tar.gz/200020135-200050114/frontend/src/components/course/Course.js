import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';
import NavBar from '../NavBar/Navbar';
import './Course.css';


axios.defaults.withCredentials = true
const Course = ({match, location}) => {
  // var course_id = ''
  const { course_id } = useParams();
  
  const [course, setCourse] = useState([]);


  const isAuthFirst = async () => {
      try {
      var res = await axios.post('http://localhost:7500/isauth')
      // console.log(res)
      console.log(res.status)
      } catch (err) {
        console.log(err)
        return window.location.href = "/login/";
      }
      
        // setIsLoggedIn(true);
       
      
    }
    const fetchDetails = async () => {
      
      var res = await axios.get('http://localhost:7500/course_details/' + course_id)
      console.log(res.data)
      setCourse(res.data)
      if(course) {
        console.log(course)
      }
      } 
    

  useEffect(() => {
    isAuthFirst();
    
    fetchDetails();
  }, []);

  
  if(course && course.pre_req_data && course.instructors_data && course.course_details) {
    
  return (
    
    <div>
      <NavBar/>
      <h2>{course.course_details.course_id} - {course.course_details.title}</h2>
      <p>Credits: {course.course_details.credits}</p>
      <h3>Prerequisites:</h3>
      <ul>
        {(course.pre_req_data).map((prereq) => (
          <li key={prereq.prereq_id}>
            <a href={`/course/${prereq.course_id}`}>{prereq.course_id}-{prereq.title}</a>
          </li>
        ))}
      </ul>
      <h3>Instructors:</h3>
      <ul>
        {course.instructors_data.map((instructor) => (
          <li key={instructor.id}>
            <Link to={`/instructor/${instructor.id}`}>{instructor.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};
}
export default Course;
