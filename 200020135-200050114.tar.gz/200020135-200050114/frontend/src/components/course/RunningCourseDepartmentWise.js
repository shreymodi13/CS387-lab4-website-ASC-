import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';
import NavBar from '../NavBar/Navbar';

axios.defaults.withCredentials = true

const RunningCourseDepartmentWise = ({match, location}) => {
    const { dept_name } = useParams();
    const [course, setCourse] = useState([]);



    const isAuthFirst = async () => {
        try {
        var res = await axios.post('http://localhost:7500/isauth')
        // console.log(res)
        console.log(res.status)
        } catch (err) {
            console.log(err)
            return window.location.href = "/login/";
        }
    }

    const fetchDetails = async () => {
        if(dept_name){
        console.log(dept_name)
        }
        var res = await axios.get('http://localhost:7500/running_courses_department/' + dept_name + '/')
      console.log(res.data)
      setCourse(res.data)
      if(course) {
        console.log(course)
      }
    }

  useEffect(() => {
        

        isAuthFirst();
        fetchDetails();
    }, []);


if(course && course.running_courses) {

 return (
    <div>
        <NavBar/>
      <h2>Running Courses</h2>
      <ul>
        {(course.running_courses).map((cour) => (
          <li key={cour.course_id}>
            <a href={`/course/${cour.course_id}`}>{cour.title}</a>
          </li>
        ))}
      </ul>
      
    </div>
  );
}
}

export default RunningCourseDepartmentWise;