import React, { useState, useEffect } from 'react';
import { ReactSearchAutocomplete } from 'react-search-autocomplete'
import axios from 'axios'
import NavBar from '../NavBar/Navbar';
axios.defaults.withCredentials = true
function Registration() {
  var search_list = []
  const [student, setStudent] = useState("");
  const [selectedSection, setSelectedSection] = useState('1');
  const [itemState, setItemState] = useState([]);
  const [select, setSelect] = useState(false);
  const [error, setError] = useState(false);

const fetchData = async () => {

  
  var temp = {}
  var final_after_change = []
  var loop_temp = {}
  const result = await axios.get("http://localhost:7500/fetch_all_courses");
  console.log(result.data)
  var list_courses = result.data.curr_course_data
  console.log(list_courses)
  if(list_courses) {
   var items = []
  list_courses.forEach((course) => {
    if(temp[course.course_id]) {
      temp[course.course_id].push(course.sec_id)
    } else {
      temp[course.course_id] = [course.sec_id]
    }
  })
  list_courses.forEach((course) => {
    
    if(!loop_temp[course.course_id]) {
      loop_temp[course.course_id] = 1
      final_after_change.push({"course_id": course.course_id, "title": course.title, "credits": course.credits, "sec_id": temp[course.course_id]})
      items.push({id: course.course_id, name: course.title})
      items.push({id: course.course_id, name: course.course_id})
    }
    setItemState(items)
  console.log(items)
})
}
setStudent(final_after_change)
}

useEffect(() => {
  isAuthFirst();
  fetchData();

}, []);
const isAuthFirst = async () => {
  try {
  var res = await axios.post('http://localhost:7500/isauth')
  // console.log(res)
  console.log(res.status)
  } catch (err) {
    console.log(err)
    return window.location.href = "/login/";
  }
  
    // setIsLoggedIn(true);
   
  
}
const handleOnSearch = async (string, results) => {
  // onSearch will have as the first callback parameter
  // the string searched and for the second the results.
  




    // the item selected
    var temp = {}
    var final_after_change = []
    var loop_temp = {}
 
    const result = await axios.post("http://localhost:7500/fetch_some_courses/", {course_id: string});
    console.log(result.data)
    var list_courses = result.data.curr_course_data
    console.log(list_courses)
    if(list_courses) {
     
     list_courses.forEach((course) => {
       if(temp[course.course_id]) {
         temp[course.course_id].push(course.sec_id)
       } else {
         temp[course.course_id] = [course.sec_id]
       }
     })
     list_courses.forEach((course) => {
       
       if(!loop_temp[course.course_id]) {
         loop_temp[course.course_id] = 1
         final_after_change.push({"course_id": course.course_id, "title": course.title, "credits": course.credits, "sec_id": temp[course.course_id]})
         
        //  items.push({id: course.course_id, name: course.course_id+"-"+course.title})
       }
      //  setItemState(items)
    //  console.log(items)
   })
   }
   setStudent(final_after_change)


}

// const handleOnHover = (result) => {
//   // the item hovered
//   console.log(result)
// }

const handleOnSelect = async (item) => {
  // the item selected
  var temp = {}
  var final_after_change = []
  var loop_temp = {}
  console.log(item.id)
  const result = await axios.post("http://localhost:7500/fetch_a_course/", {course_id: item.id});
  console.log(result.data)
  var list_courses = result.data.curr_course_data
  console.log(list_courses)
  if(list_courses) {
   
   list_courses.forEach((course) => {
     if(temp[course.course_id]) {
       temp[course.course_id].push(course.sec_id)
     } else {
       temp[course.course_id] = [course.sec_id]
     }
   })
   list_courses.forEach((course) => {
     
     if(!loop_temp[course.course_id]) {
       loop_temp[course.course_id] = 1
       final_after_change.push({"course_id": course.course_id, "title": course.title, "credits": course.credits, "sec_id": temp[course.course_id]})
      //  items.push({id: course.course_id, name: course.course_id+"-"+course.title})
     }
    //  setItemState(items)
  //  console.log(items)
 })
 }
 setStudent(final_after_change)
 }




// const handleOnFocus = () => {
//   console.log('Focused')
// }

const formatResult = (item) => {
  return (
    <>
      {/* <span style={{ display: 'block', textAlign: 'left' }}>id: {item.id}</span> */}
      <span style={{ display: 'block', textAlign: 'left' }}>{item.name}</span>
    </>
  )
}
const handleRegisterCourse = async (courseId, secId) => {

  var res = await axios.post('http://localhost:7500/register_course', {"course_id": courseId, "sec_id": secId})
  console.log(res)
  if(res.data.error) {

    alert(res.data.error)
    window.location.reload()
  }
  else {
    alert("Course Registered Successfully")
    window.location.reload()
  }

};

if(student && itemState) {
return (
  <div className="App">
    <NavBar />
        <ReactSearchAutocomplete
          items={itemState}
          onSearch={handleOnSearch}
          // onHover={handleOnHover}
          onSelect={handleOnSelect}
          // onFocus={handleOnFocus}
          autoFocus
          formatResult={formatResult}
        />
     
  
<div>
<h2>Current Semester Courses</h2>
<table>
  <thead>
    <tr>
      <th> Course ID</th>
      <th>Course Name</th>
      <th>Credits</th>
      <th> Section</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    {student
     .map(course => (
      
       <tr key={course.course_id}>
         <td>{course.course_id}</td>
         <td>{course.title}</td>
         <td>{course.credits}</td>
         <td>
         <select onChange={e => setSelectedSection(e.target.value)}>
            {course.sec_id.map(section => (
              <option key={section} value={section}>
                {section}
              </option>
            ))}
          </select>
         </td>
         <td>
           <button onClick={() => handleRegisterCourse(course.course_id, selectedSection)}>
             Register Course
           </button>
         </td>
       </tr>
       
     ))}
     
 </tbody>
</table>
</div> 

</div>
)
}

}
export default Registration;
// export default Course;

