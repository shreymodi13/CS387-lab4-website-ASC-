import React from 'react';
import './navbar.css'
import axios from 'axios';

axios.defaults.withCredentials = true
const NavBar = () => {

  const handleLogout = async () => {
    const res = await axios.get('http://localhost:7500/logout')
    if(res.data.error) {
     alert(res.data.error)
    }
    else {
      alert("Logged out successfully!")
      window.location.href = "/login/";
    }



  }

  return (
    <nav>
      <ul>
        <li><a href="/home">Home</a></li>
        <li><a href = "/home/registration">Registration</a></li>
        <li><a href = "/course/running/">Running Courses</a></li>
        <li><button onClick={() => handleLogout()}>
                    Logout
                  </button></li>
      </ul>
    </nav>
  );
};

export default NavBar;
