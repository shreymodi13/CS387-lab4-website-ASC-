import React from 'react'

export default function Student_Info() {
  return (
    <div>
      <p>Name:</p>
      <p>ID:</p>
    </div>
  )
}
