import React from 'react'
import Table from 'react-bootstrap/Table'


const Grid = ({grid}) => {

    return (
      <table>
        <tbody>
          {grid.map((row, i) => (
            <tr key={i}>
              {row.map((col, j) => (
                <td key={j}>{col}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
       
    
    }
  
  export default Grid;
  
    
