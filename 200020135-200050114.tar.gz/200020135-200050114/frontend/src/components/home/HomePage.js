import React, { useState, useEffect } from 'react';
import axios from 'axios'
import NavBar from '../NavBar/Navbar';
import './HomePage.css'
axios.defaults.withCredentials = true

const HomePage = () => {
  const [student, setStudent] = useState({});
  const [courses, setCourses] = useState([]);
  const [dropButtonClick, setDropButtonClick] = useState(false);
  var mapp = {
    "Spring": 3,
    "Summer": 2,
    "Fall": 1,
    "Winter": 0
    
  }
  var year_wise = []
  var course_grouping = []
  const isAuthFirst = async () => {
    try {
    var res = await axios.post('http://localhost:7500/isauth')
    // console.log(res)
    console.log(res.status)
    } catch (err) {
      console.log(err)
      return window.location.href = "/login/";
    }
    
      // setIsLoggedIn(true);
     
    
  }
  const getStudentDetails = async () => {
    try {
    var res = await axios.get('http://localhost:7500/home_data')
   console.log(res.data)
     setStudent(res.data)

    } catch (err) {
      console.log(err)
      return window.location.href = "/login/";
    }
    // console.log(student)
    // console.log("1111111")
  }
  const handleDropCourse = async (courseId) => {
    // Example API call to drop a course
    // setDropButtonClick(true);
    var res = await axios.post('http://localhost:7500/drop', {"course_id": courseId})
    
    if(res.data.error) {
      alert(res.data.error)
      window.location.reload();
    } else {
      alert("Course dropped successfully!")
      window.location.reload();
    }
    // setDropButtonClick(true);
  }



  useEffect(() => {
    // Example API call to retrieve student information
    isAuthFirst();

    getStudentDetails();
    
    // Example API call to retrieve courses information
    // fetch('/api/courses')
    //   .then(res => res.json())
    //   .then(courses => setCourses(courses))
    //   .catch(error => console.error(error));
  }, []);
  useEffect(() => {
    if(student.course_data) {
      console.log(student.course_data)
    
    }
  }, [student])
  // const groupedCourses = student.course_data.reduce((groupedCourses, course) => {
  //   const semester = course.semester;
  //   if (!groupedCourses[semester]) {
  //     groupedCourses[semester] = [];
  //   }
  //   groupedCourses[semester].push(course);
  //   return groupedCourses;
  // }, {});


//   const groupingLogic = async () => {
//     if(student.course_data) {
//     var max_year = 0
//     student.course_data.forEach((course) => {
//       if (course.year > max_year) {
//         max_year = course.year
//       }
//     })
//     student.course_data.forEach((course) => {
//       var diff = max_year - course.year
//       if(!course_grouping[diff]) {
//         course_grouping[diff] = [[]]
//         course_grouping[diff][mapp[course.semester]] = [course]

//       }
//       else if(!course_grouping[diff][mapp[course.semester]]) {
//         course_grouping[diff][mapp[course.semester]] = [course]
//       }
//       else {
//         course_grouping[diff][mapp[course.semester]].push(course)
//       }
//     })
//   }
//   console.log(course_grouping)
// }
  // const groupedCourses = (student.course_data).reduce((groupedCourses, course) => {
  //   console.log(student.id)
  //   const semester = course.semester;
  //   const year = course.year;
  
  //   if (!groupedCourses[year]) {
  //     groupedCourses[year] = {};
  //   }
  
  //   if (!groupedCourses[year][semester]) {
  //     groupedCourses[year][semester] = [];
  //   }
  
  //   groupedCourses[year][semester].push(course);
    
  //   return groupedCourses;
  // }, {});

  // useEffect(() => {
    
  //   groupedCourses();

  // }, [student]);
  if(student.course_data) {
  return (
    <div className="HomePage">
      <NavBar />
      <h1>Student Information</h1>
      <table>
        <tbody>
          <tr>
            <td>ID:</td>
            <td>{student.id}</td>
          </tr>
          <tr>
            <td>Name:</td>
            <td>{student.name}</td>
          </tr>
          <tr>
            <td>Department:</td>
            <td>{student.dept_name}</td>
          </tr>
          <tr>
            <td>Total Credits:</td>
            <td>{student.tot_cred}</td>
          </tr>
        </tbody>
    </table>
      
    
      {(student.course_data).map((row)=>(
          <><h2>YEAR:{row.year} SEMESTER:{row.semester}</h2>
          <table>
              <thead>
                <tr>
                  <th>Course Code</th>
                  <th>Course Name</th>
                  <th>Section</th>
                  <th>Grade</th>
                </tr>
              </thead>
              <tbody>
                {row.rows.map((item) => (
                  <tr>
                  <td>{item.split(',')[1]}</td>
                  <td>{item.split(',')[2]}</td>
                  <td>{item.split(',')[3]}</td>
                  <td>{item.split(',')[4]}</td>
                </tr>
                
                ))}
                </tbody>
          </table>
          </>
      ))}
                        

       <h2>Current Semester Courses</h2>
       <table>
         <thead>
           <tr>
             <th> Course ID</th>
             <th>Course Name</th>
             <th>Credits</th>
             <th> Grade</th>
             <th>Action</th>
           </tr>
         </thead>
         <tbody>
           {student.curr_course_data
            .map(course => (
              <tr key={course.course_id}>
                <td>{course.course_id}</td>
                <td>{course.title}</td>
                <td>{course.credits}</td>
                <td>{course.grade}</td>
                <td>
                  <button onClick={() => handleDropCourse(course.course_id)}>
                    Drop Course
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table> 
    </div>
  );
            }       
          }  


export default HomePage;