import React from 'react'
import Table from 'react-bootstrap/Table'
export default function This_Sem() {
  return (
   
    <Table striped bordered hover variant="dark">
    {/* <Table className="table table-dark table-striped"> */} 

      <thead>
        <tr>
          <th>Course Code</th>
          <th>Course Name </th>
          <th>Tag</th>
          <th>Credits</th>
          <th>Grade</th>
          <th>Credit/Audit</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>CS302</td>
          <td>IPL</td>
          <td>Core Course</td>
          <td>8</td>
          <td>AA</td>
          <td></td>
          <td>C</td>
        </tr>
        <tr>
        <td>CS302</td>
          <td>IPL</td>
          <td>Core Course</td>
          <td>8</td>
          <td>AA</td>
          <td></td>
          <td>C</td>
        </tr>
        <tr>
        <td>CS302</td>
          <td>IPL</td>
          <td>Core Course</td>
          <td >8</td>
          <td>AA</td>
          <td></td>
          <td>C</td>
        </tr>
        <tr>
        <td>CS302</td>
          <td>IPL</td>
          <td>Core Course</td>
          <td>8</td>
          <td>AA</td>
          <td></td>
          <td>C</td>
        </tr>
        <tr>
        <td>CS302</td>
          <td>IPL</td>
          <td>Core Course</td>
          <td>8</td>
          <td>AA</td>
          <td></td>
          <td>C</td>
        </tr>
      </tbody>
    </Table>
  )
}
