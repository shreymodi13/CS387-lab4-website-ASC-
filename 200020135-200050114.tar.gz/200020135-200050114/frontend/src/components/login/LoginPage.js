

import React, { useState, useEffect } from "react";
import axios from 'axios'
import './login.css';
axios.defaults.withCredentials = true
const Login = () => {
  const [studentId, setStudentId] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = async (event) => {
    event.preventDefault();
    var res = await axios.post('http://localhost:7500/login', {"username" : studentId, "password" : password})
    console.log(res);
    // Perform login logic here, check studentId and password against some data source
    setIsLoggedIn(true);
  };

  const isAuthFirst = async () => {
    var res = await axios.post('http://localhost:7500/isauth')
    console.log(res)
    if (res.status == 200) {
      // setIsLoggedIn(true);
      return window.location.href = "/home/";
    }
  }

  useEffect(() => {
    // Example API call to retrieve student information
    isAuthFirst();

    
  }, []);



  // if (isLoggedIn) {
  //   // Redirect to the home page, you can use window.location.href = "/"
  //   return window.location.href = "/home/";
  // }
  if (!isLoggedIn) {
  return (
    <form onSubmit={handleLogin}>
      <input
        type="text"
        placeholder="Student ID"
        value={studentId}
        onChange={(event) => setStudentId(event.target.value)}
      />
      <br/>
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(event) => setPassword(event.target.value)}
      />
      <br/>
      <button type="submit">Login</button>
    </form>
  );
}
else {
  return window.location.href = "/home/";
}
}
export default Login;
