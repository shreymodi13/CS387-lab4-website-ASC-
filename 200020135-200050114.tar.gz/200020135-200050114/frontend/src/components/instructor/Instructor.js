import React,  { useState, useEffect }from "react";
import { Link, Route, useParams } from "react-router-dom";
import "./instructor.css"
import axios from "axios";
import NavBar from '../NavBar/Navbar';

axios.defaults.withCredentials = true

const Instructor = () => {
  const { instructor_id } = useParams();
  const [instructor, setInstructor] = useState([]);

  const isAuthFirst = async () => {
    try {
    var res = await axios.post('http://localhost:7500/isauth')
    // console.log(res)
    console.log(res.status)
    } catch (err) {
        console.log(err)
        return window.location.href = "/login/";
    }
}

const fetchDetails = async () => {
    
    var res = await axios.get('http://localhost:7500/instructor_details/' + instructor_id + '/')
  console.log(res.data)
  setInstructor(res.data)
  
}

useEffect(() => {
    

    isAuthFirst();
    fetchDetails();
}, []);


if(instructor && instructor.instructor_details && instructor.current_courses_data && instructor.past_courses_data) {
  return (
    <div>
      <NavBar/>
      <h2>{instructor.instructor_details.name}</h2>
      <p>Department: {instructor.instructor_details.dept_name}</p>

      <h3>Current Semester Courses</h3>
      <ul>
        {instructor.current_courses_data.map(course => (
          <li key={course.course_id}>
            <a href={`/course/${course.course_id}`}>{course.course_id} - {course.title}</a>
          </li>
        ))}
      </ul>

      <h3>Past Courses</h3>
      {(instructor.past_courses_data).map((row)=>(
          <><h2>YEAR:{row.year} SEMESTER:{row.semester}</h2>
          
              
          <ul>
                {row.rows.map((item) => (
                  <li key = {item}>
                  <>{item.split(',')[0]}-{item.split(',')[1]}</>
                  </li>
                ))}
          </ul>
                  
                
               
                
          
          </>
      ))}
    </div>
  );
};
}
export default Instructor;
