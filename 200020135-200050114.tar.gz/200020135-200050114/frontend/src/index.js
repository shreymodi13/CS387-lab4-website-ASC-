import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
// import SearchBox from './components/reg/Registration';
import Courses from './components/reg/Registration'
// import CourseL
import LoginPage from './components/login/LoginPage.js';
import NavBar from './components/NavBar/Navbar';
import HomePage from './components/home/HomePage';
import Course from './components/course/Course';
import SearchBox from './components/reg/Registration';
import Instructor from './components/instructor/Instructor';
// import SemTable from 'react-bootstrap/SemTable'
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <Instructor instructor="Abhiram Ranade" courses="CS101" /> */}
    
    <App />
    <>
    {/* <  SearchBox/>     */}
    {/* <Courses/> */}
    </>
    {/* <HomePage studentId="200050114" name="Radhika" department="cse" totalCredits="180" courses="cs101"/> */}
    {/* <Course courseId="CS101" courseName="Computer Programming and Utilization" credits="6" venue="Online" prerequisites="None" instructors="Bhaskaran Raman"/> */}
    
      
   </React.StrictMode>
  
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();






// const express = require("express");
// // const path=require('path')
// const app = express();
// const bodyParser = require("body-parser");

// app.use(bodyParser.json());
// app.use()
// // app.post("/login", (req, res) => {
// //   const { username, password } = req.body;
// //   if (username === "admin" && password === "password") {
// //     req.session.user = { username };
// //     res.json({ success: true });
// //   }
// // })

// app.listen(5000,()=>{
//   console.log("radhika");
// });


// const express = require('express');
// const session = require('express-session');
// const app = express();
// const cors = require('cors');
// const pool = require('./db');
// const bcrypt = require('bcryptjs');
// const cookieParser = require('cookie-parser')


// app.use(cors());
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(cookieParser())
// app.use(express.static(__dirname));
// const store = new (require('connect-pg-simple')(session))({
//     pool: pool,
// })
// const isAuth = (req, res, next) => {
//     if (req.session.user) {
//         if (req.session.user.isAuth) {
//             return next()
//         }
       
//     }
//     return res.sendStatus(403)
// }

// app.use(
//     session({
//         store: store,
//         secret: "this is a secret key",
//         saveUninitialized: false,
//         resave: false,
//         cookie: {
//             secure: false,
//             httpOnly: false,
//             sameSite: false,
//             maxAge: 1000 * 60 * 60 * 24,
//         },
//     })
// )

// app.listen(3000, () => {
//     console.log('Server running on port 3000');
//     });
    

// // Path: routes/index.js
// app.post('/register', async (req, res) => {
//     const { username, password } = req.body

//     if (username == null ||
//         password == null
//     ) {
//         return res.sendStatus(403)
//     }

//     try {
//         const saltRound = 10;
//         const salt = await bcrypt.genSalt(saltRound);
//         const hashedPassword = await bcrypt.hash(password, salt);
//         // const hashedPassword = bcrypt.hashSync(req.body.password, 10)
//         const data = await pool.query(
//             'INSERT INTO user_password (id, hashed_password) VALUES ($1, $2) RETURNING *',
//             [username, hashedPassword]
//         )

//         if (data.rows.length === 0) {
//             res.sendStatus(403)
//         }
//         const user = data.rows[0]
//         // console.log(user)
//         req.session.user = {
//             id: user.id,
//             isAuth:true
//         }

//         res.status(200)
//         res.redirect('/login')
//         // return res.json({ user: req.session.user })
//     } catch (e) {
//         console.error(e)
//         return res.sendStatus(403)
//     }
// }
// )

// app.post('/login', async (req, res) => {
//     const { username, password } = req.body

//     if (username == null || password == null) {
//         return res.sendStatus(403)
//     }
    
//     try {
//         const data = await pool.query(
//             'SELECT id, hashed_password FROM user_password WHERE id = $1',
//             [username]
//         )

//         if (data.rows.length === 0) {
//             return res.sendStatus(403)
//         }
//         const user = data.rows[0]
//         const matches = await bcrypt.compare(password, user.hashed_password)
//         // const matches = bcrypt.compareSync(password, user.hashed_password)
//         if (!matches) {
//             return res.sendStatus(403)
//         }

//         req.session.user = {
//             id: user.id,
//             isAuth:true
//         }

//         res.status(200)
//         res.redirect('/home')
//         // return res.json({ user: req.session.user })
//     } catch (e) {
//         console.error(e)
//         return res.sendStatus(403)
//     }
// }
// )
// app.get("/home", isAuth, (req, res) => {
//     res.send("Welcome to home page")
// })
// app.get('/',(req,res) => {
   
//     if(req.session.user){
//         if(req.session.user.isAuth){
//         res.send("Welcome User <a href=\'/logout'>click to logout</a>");
//         }
//     }else
//     res.sendFile('views/index.html',{root:__dirname})
// });


// app.get('/logout',(req,res) => {
//     req.session.destroy();
//     res.redirect('/');
// });