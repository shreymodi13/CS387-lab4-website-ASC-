// import logo from './logo.svg';
import {
  BrowserRouter,
  Navigate,
  Routes,
  Route,
  Outlet,
} from 'react-router-dom'
import './App.css';
import Homepage from'./components/home/HomePage'
import Login from './components/login/LoginPage'
import SearchBox from './components/reg/Registration';
import Course from './components/course/Course'
import Instructor from './components/instructor/Instructor'
import RunningCourse from './components/course/RunningCourse'
import RunningCourseDepartmentWise from './components/course/RunningCourseDepartmentWise'
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/home" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home/registration" element={<SearchBox />} />
        <Route path="/course/:course_id" element={<Course />} />
        <Route path = "/course/running/" element = {<RunningCourse />} />
        <Route path = "/course/running/:dept_name" element = {<RunningCourseDepartmentWise />} />
        <Route path="/instructor/:instructor_id" element={<Instructor />} />
      </Routes>
    </BrowserRouter>
    
    
    

  );
}

export default App;
